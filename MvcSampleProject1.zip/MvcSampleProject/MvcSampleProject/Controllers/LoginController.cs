﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcSampleProject.Models;

namespace MvcSampleProject.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Login/
        public StudentContext db = new StudentContext();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Login lm)
        {
            var u = db.Registrations.Where(x => x.username == lm.Uname & x.password == lm.Pwd).FirstOrDefault();
            if (u == null)
            {
                ModelState.AddModelError("", "Invalid Username or Password");
                return View();
            }
            return RedirectToAction("Index", "Home");
        }  
    }
}
