﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcSampleProject.Models
{
    public class Department
    {
        public int DepartmentId { get; set; }
      
        [Required]
        [Display(Name = "Department Name:")]
        public String dname { get; set; }
        public virtual Registration Register { get; set; }
    }
}