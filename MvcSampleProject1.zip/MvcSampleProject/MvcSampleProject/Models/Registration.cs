﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace MvcSampleProject.Models
{
    public class Registration
    {
        
        public int RegistrationId { get; set; }
        [Required]
        [Display(Name="User Name:")]
        public String username { get; set; }
        [Required]
        [Display(Name = "User Password:")]
        [DataType(DataType.Password)]
        public String password { get; set; }
        [Required]
        [Display(Name = "Name:")]
        public String name { get; set; }
        [Required]
        [Display(Name = "User Address:")]
        [DataType(DataType.MultilineText)]
        public String address { get; set; }
        [Required]
        [Display(Name = "User Email:")]
        [DataType(DataType.EmailAddress,ErrorMessage="Invalid Email")]
        public String email { get; set; }
        public Gender Genderlist { get; set; }
    }
    public enum Gender
    {
        Male,
        Female
    }
}